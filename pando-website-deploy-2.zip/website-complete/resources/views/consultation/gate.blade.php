<x-app-layout>
    <x-slot name="title">Before You Start — {{ $product->name }}</x-slot>

    <div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

        <div class="mb-8">
            <a href="{{ route('products.show', [$product->treatmentCategory, $product]) }}"
               class="inline-flex items-center gap-1 text-sm text-plum-500 hover:text-plum-700 transition-colors">
                &larr; Back to {{ $product->name }}
            </a>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-plum-100 p-8">

            <h1 class="text-2xl font-bold text-plum-900 mb-2">Before you start</h1>
            <p class="text-plum-500 mb-8">Please confirm you meet the eligibility criteria for <strong>{{ $product->name }}</strong>.</p>

            <div class="space-y-4 mb-8">
                <div class="flex items-start gap-3 p-4 rounded-xl bg-plum-50 border border-plum-100">
                    <span class="text-plum-400 mt-0.5">
                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </span>
                    <p class="text-sm text-plum-700">You are 18 years of age or older.</p>
                </div>
                <div class="flex items-start gap-3 p-4 rounded-xl bg-plum-50 border border-plum-100">
                    <span class="text-plum-400 mt-0.5">
                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </span>
                    <p class="text-sm text-plum-700">You are based in England, Scotland, or Wales.</p>
                </div>
                <div class="flex items-start gap-3 p-4 rounded-xl bg-plum-50 border border-plum-100">
                    <span class="text-plum-400 mt-0.5">
                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </span>
                    <p class="text-sm text-plum-700">You understand this service is for supply of prescription medication and you will answer all consultation questions honestly.</p>
                </div>
            </div>

            <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-8">
                <p class="text-sm text-amber-800">
                    <strong>Important:</strong> This is a clinical service. Providing false or misleading information
                    may result in medication being supplied unsafely. Our prescribers review every consultation.
                </p>
            </div>

            <div class="flex flex-col sm:flex-row gap-3">
                <a href="{{ route('consultation.start', $product) }}"
                   class="flex-1 inline-flex items-center justify-center px-6 py-3 bg-plum-600 hover:bg-plum-700
                          text-white font-semibold rounded-xl transition-colors text-center">
                    I confirm — start consultation
                </a>
                <a href="{{ route('products.show', [$product->treatmentCategory, $product]) }}"
                   class="flex-1 inline-flex items-center justify-center px-6 py-3 bg-white hover:bg-plum-50
                          text-plum-700 font-semibold rounded-xl border border-plum-200 transition-colors text-center">
                    Go back
                </a>
            </div>

        </div>
    </div>

</x-app-layout>
