<?php
/**
 * Pando CRM — One-Click Setup
 * Upload this file along with the full project, then visit:
 *   https://crm.yourdomain.com/setup.php  (or run: php setup.php from the project root)
 *
 * IMPORTANT: Delete this file after setup is complete.
 */

define('IS_CLI', PHP_SAPI === 'cli');

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function out(string $msg, string $type = 'info'): void {
    if (IS_CLI) {
        $prefix = match($type) { 'ok' => '✓ ', 'error' => '✗ ', 'warn' => '⚠ ', default => '  ' };
        echo $prefix . $msg . "\n";
    } else {
        $cls = match($type) { 'ok' => 'ok', 'error' => 'err', 'warn' => 'warn', default => 'info' };
        echo "<div class=\"log $cls\">" . h($msg) . "</div>\n";
        flush(); ob_flush();
    }
}

function run(string $cmd): array {
    exec($cmd . ' 2>&1', $lines, $code);
    return ['output' => implode("\n", $lines), 'code' => $code];
}

function findPhp(): string {
    foreach ([PHP_BINARY, 'php8.3', 'php8.2', 'php8.1', 'php8', 'php'] as $bin) {
        $r = run("which $bin");
        if ($r['code'] === 0 && $r['output']) return trim($r['output']);
    }
    return PHP_BINARY;
}

function rootDir(): string { return rtrim(dirname(__FILE__), '/'); }

function stepCheckRequirements(): bool {
    out('Checking server requirements…');
    $ok = true;
    if (version_compare(PHP_VERSION, '8.2.0', '<')) {
        out('PHP 8.2+ required. Found: ' . PHP_VERSION, 'error'); $ok = false;
    } else {
        out('PHP ' . PHP_VERSION, 'ok');
    }
    foreach (['pdo', 'pdo_mysql', 'mbstring', 'openssl', 'tokenizer', 'xml', 'ctype', 'json', 'bcmath', 'curl', 'zip', 'fileinfo'] as $ext) {
        if (!extension_loaded($ext)) { out("Missing PHP extension: $ext", 'error'); $ok = false; }
    }
    if ($ok) out('All required PHP extensions present', 'ok');
    $root = rootDir();
    foreach (['storage/app', 'storage/framework/cache', 'storage/framework/sessions', 'storage/framework/views', 'storage/logs', 'bootstrap/cache'] as $dir) {
        $path = "$root/$dir";
        if (!is_dir($path)) @mkdir($path, 0755, true);
        if (!is_writable($path)) { out("Not writable: $dir", 'error'); $ok = false; }
    }
    if ($ok) out('Storage directories writable', 'ok');
    return $ok;
}

function stepGetComposer(): string {
    $root = rootDir();
    $pharPath = "$root/composer.phar";
    if (is_file($pharPath)) { out('composer.phar already present', 'ok'); return $pharPath; }
    out('Downloading composer.phar…');
    $sig = file_get_contents('https://composer.github.io/installer.sig');
    $installer = file_get_contents('https://getcomposer.org/installer');
    if (!$installer) { out('Could not download Composer. Upload composer.phar manually.', 'error'); return ''; }
    if (hash('sha384', $installer) !== trim($sig)) { out('Composer signature mismatch.', 'error'); return ''; }
    file_put_contents("$root/composer-setup.php", $installer);
    $php = findPhp();
    run("$php $root/composer-setup.php --install-dir=$root --filename=composer.phar");
    @unlink("$root/composer-setup.php");
    if (!is_file($pharPath)) { out('Failed to install Composer.', 'error'); return ''; }
    out('Composer installed', 'ok');
    return $pharPath;
}

function stepInstallVendor(string $composerPhar): bool {
    $root = rootDir();
    if (is_dir("$root/vendor/laravel")) { out('vendor/ already present', 'ok'); return true; }
    out('Running composer install (1–2 minutes)…');
    $php = findPhp();
    $r = run("cd $root && $php $composerPhar install --no-dev --optimize-autoloader --no-interaction");
    if ($r['code'] !== 0) { out('composer install failed: ' . $r['output'], 'error'); return false; }
    out('PHP dependencies installed', 'ok');
    return true;
}

function stepWriteEnv(array $cfg): bool {
    $root = rootDir();
    $envPath = "$root/.env";
    if (is_file($envPath) && !isset($_POST['overwrite_env'])) {
        out('.env already exists — skipping', 'warn'); return true;
    }
    $template = file_get_contents("$root/env.crm.production");
    if (!$template) { out('env.crm.production template not found', 'error'); return false; }

    $replacements = [
        'APP_URL=https://crm.prescribeandco.co.uk' => 'APP_URL=' . $cfg['app_url'],
        'DB_DATABASE=pando_production' => 'DB_DATABASE=' . $cfg['db_database'],
        'DB_USERNAME=pando_user'       => 'DB_USERNAME=' . $cfg['db_username'],
        'DB_PASSWORD='                 => 'DB_PASSWORD=' . $cfg['db_password'],
        'DB_HOST=127.0.0.1'            => 'DB_HOST=' . ($cfg['db_host'] ?: '127.0.0.1'),
        'SENDGRID_API_KEY='            => 'SENDGRID_API_KEY=' . $cfg['sendgrid_key'],
        'STRIPE_KEY=pk_live_'          => 'STRIPE_KEY=' . $cfg['stripe_key'],
        'STRIPE_SECRET=sk_live_'       => 'STRIPE_SECRET=' . $cfg['stripe_secret'],
        'STRIPE_WEBHOOK_SECRET=whsec_' => 'STRIPE_WEBHOOK_SECRET=' . $cfg['stripe_webhook'],
        'SUPER_ADMIN_EMAIL=admin@prescribeandco.co.uk' => 'SUPER_ADMIN_EMAIL=' . $cfg['admin_email'],
        'SUPER_ADMIN_PASSWORD='        => 'SUPER_ADMIN_PASSWORD=' . $cfg['admin_password'],
        'CRM_IP_WHITELIST=127.0.0.1'   => 'CRM_IP_WHITELIST=' . $cfg['ip_whitelist'],
        'PHARMACY_GPHC_NUMBER='        => 'PHARMACY_GPHC_NUMBER=' . $cfg['gphc'],
        'PHARMACY_ADDRESS="Your Registered Pharmacy Address, UK"' => 'PHARMACY_ADDRESS="' . $cfg['pharmacy_address'] . '"',
        'PHARMACY_PHONE='              => 'PHARMACY_PHONE=' . $cfg['pharmacy_phone'],
    ];

    foreach ($replacements as $find => $replace) {
        $template = str_replace($find, $replace, $template);
    }

    if (!file_put_contents($envPath, $template)) { out('Could not write .env', 'error'); return false; }
    out('.env written', 'ok');
    return true;
}

function stepArtisan(string $command, string $label): bool {
    $root = rootDir(); $php = findPhp();
    $r = run("cd $root && $php artisan $command");
    if ($r['code'] !== 0) { out("$label failed: " . $r['output'], 'error'); return false; }
    out($label, 'ok'); return true;
}

function stepMigrate(bool $seedStaff, bool $seedWorkflow): bool {
    $ok = stepArtisan('key:generate --force', 'App key generated');
    // CRM migrations only (website must be migrated first — shared tables already exist)
    $ok = stepArtisan('migrate --force', 'Database migrations') && $ok;
    if ($seedStaff)    $ok = stepArtisan('db:seed --class=StaffSeeder --force', 'Staff seeded (Super Admin account)') && $ok;
    if ($seedWorkflow) $ok = stepArtisan('db:seed --class=WorkflowRuleSeeder --force', 'Workflow rules seeded') && $ok;
    return $ok;
}

function stepCache(): void {
    stepArtisan('config:cache', 'Config cached');
    stepArtisan('route:cache', 'Routes cached');
    stepArtisan('view:cache', 'Views cached');
}

// ── CLI ───────────────────────────────────────────────────────────────────────
if (IS_CLI) {
    echo "\n=== Pando CRM Setup ===\n\n";
    if (!stepCheckRequirements()) { exit(1); }
    $composer = stepGetComposer();
    if (!$composer || !stepInstallVendor($composer)) exit(1);
    if (!is_file(rootDir() . '/.env')) {
        echo "\n.env not found. Copy env.crm.production to .env and fill in credentials, then re-run.\n";
        exit(1);
    }
    stepMigrate(true, true);
    stepCache();
    echo "\n✓ Setup complete. Delete this file: rm setup.php\n\n";
    exit(0);
}

// ── Web UI ────────────────────────────────────────────────────────────────────
session_start();
$errors = []; $success = false; $logs = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_start();
    $cfg = [
        'app_url'          => rtrim($_POST['app_url'] ?? '', '/'),
        'db_host'          => $_POST['db_host'] ?? '127.0.0.1',
        'db_port'          => $_POST['db_port'] ?? '3306',
        'db_database'      => $_POST['db_database'] ?? '',
        'db_username'      => $_POST['db_username'] ?? '',
        'db_password'      => $_POST['db_password'] ?? '',
        'sendgrid_key'     => $_POST['sendgrid_key'] ?? '',
        'stripe_key'       => $_POST['stripe_key'] ?? '',
        'stripe_secret'    => $_POST['stripe_secret'] ?? '',
        'stripe_webhook'   => $_POST['stripe_webhook'] ?? '',
        'admin_email'      => $_POST['admin_email'] ?? '',
        'admin_password'   => $_POST['admin_password'] ?? '',
        'ip_whitelist'     => $_POST['ip_whitelist'] ?? '127.0.0.1',
        'gphc'             => $_POST['gphc'] ?? '',
        'pharmacy_address' => $_POST['pharmacy_address'] ?? '',
        'pharmacy_phone'   => $_POST['pharmacy_phone'] ?? '',
    ];

    if (empty($cfg['app_url']))       $errors[] = 'CRM URL is required';
    if (empty($cfg['db_database']))   $errors[] = 'Database name is required';
    if (empty($cfg['db_username']))   $errors[] = 'Database username is required';
    if (empty($cfg['admin_email']))   $errors[] = 'Super Admin email is required';
    if (empty($cfg['admin_password'])) $errors[] = 'Super Admin password is required';

    if (empty($errors)) {
        $allOk = stepCheckRequirements();
        if ($allOk) {
            $composer = stepGetComposer();
            if ($composer && stepInstallVendor($composer)) {
                if (stepWriteEnv($cfg)) {
                    if (stepMigrate(isset($_POST['seed_staff']), isset($_POST['seed_workflow']))) {
                        stepCache();
                        $success = true;
                    }
                }
            }
        }
    }
    $logs = ob_get_clean();
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pando CRM — Setup</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#faf5ff;color:#1e1b4b;min-height:100vh;display:flex;align-items:flex-start;justify-content:center;padding:2rem 1rem}
  .card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(80,40,160,.12);padding:2.5rem;width:100%;max-width:680px}
  h1{font-size:1.5rem;font-weight:700;color:#4c1d95;margin-bottom:.25rem}
  .sub{color:#6b7280;font-size:.9rem;margin-bottom:2rem}
  .notice{background:#fffbeb;border:1px solid #fcd34d;border-radius:8px;padding:1rem;margin-bottom:1.5rem;font-size:.875rem;color:#92400e}
  h2{font-size:1rem;font-weight:600;color:#4c1d95;margin:1.5rem 0 .75rem;padding-bottom:.4rem;border-bottom:1px solid #ede9fe}
  label{display:block;font-size:.85rem;font-weight:500;color:#374151;margin-bottom:.3rem}
  input{width:100%;padding:.55rem .75rem;border:1.5px solid #d1d5db;border-radius:8px;font-size:.9rem;outline:none;transition:border .2s}
  input:focus{border-color:#7c3aed}
  .row{display:grid;gap:1rem;margin-bottom:1rem}
  .row.two{grid-template-columns:1fr 1fr}
  .row.three{grid-template-columns:2fr 1fr 1fr}
  .hint{font-size:.78rem;color:#9ca3af;margin-top:.25rem}
  .checkbox-row{display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem}
  .checkbox-row input{width:auto}
  .btn{width:100%;padding:.8rem;background:#7c3aed;color:#fff;border:none;border-radius:8px;font-size:1rem;font-weight:600;cursor:pointer;margin-top:1.5rem;transition:background .2s}
  .btn:hover{background:#6d28d9}
  .errors{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:1rem;margin-bottom:1.5rem}
  .errors li{color:#dc2626;font-size:.875rem;margin-left:1rem}
  .log-box{background:#1e1b4b;border-radius:8px;padding:1rem;margin-bottom:1.5rem;max-height:320px;overflow-y:auto;font-family:monospace;font-size:.82rem}
  .log{padding:.2rem 0;color:#c4b5fd}
  .log.ok{color:#86efac}
  .log.err{color:#fca5a5}
  .log.warn{color:#fcd34d}
  .success{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:1.25rem;text-align:center}
  .success h3{color:#15803d;font-size:1.1rem;font-weight:700}
  .success p{color:#166534;font-size:.875rem;margin-top:.5rem}
  .badge{display:inline-block;background:#ede9fe;color:#6d28d9;border-radius:999px;padding:.2rem .75rem;font-size:.78rem;font-weight:600;margin-bottom:1rem}
</style>
</head>
<body>
<div class="card">
  <div class="badge">CRM</div>
  <h1>🔐 Pando CRM Setup</h1>
  <p class="sub">Configure and launch the internal pharmacy CRM.</p>

  <div class="notice">
    ⚠️ <strong>Run the Website setup first.</strong> The website migrations create the shared database tables that the CRM depends on.
  </div>

  <?php if (!empty($errors)): ?>
    <div class="errors"><ul><?php foreach($errors as $e): ?><li><?=h($e)?></li><?php endforeach ?></ul></div>
  <?php endif ?>

  <?php if ($logs): ?>
    <div class="log-box"><?= $logs ?></div>
  <?php endif ?>

  <?php if ($success): ?>
    <div class="success">
      <h3>✓ CRM setup complete!</h3>
      <p>The CRM is ready at <strong><?=h($_POST['app_url']??'')?></strong>.</p>
      <p style="margin-top:.5rem"><strong>Delete <code>setup.php</code> immediately.</strong></p>
    </div>
  <?php else: ?>

  <form method="POST">
    <h2>Application</h2>
    <div class="row">
      <div>
        <label>CRM URL</label>
        <input name="app_url" type="url" value="<?=h($_POST['app_url']??'https://crm.')?>" placeholder="https://crm.prescribeandco.co.uk" required>
      </div>
    </div>

    <h2>Database (same credentials as website)</h2>
    <div class="row three">
      <div>
        <label>Database Host</label>
        <input name="db_host" value="<?=h($_POST['db_host']??'127.0.0.1')?>">
      </div>
      <div>
        <label>Port</label>
        <input name="db_port" value="<?=h($_POST['db_port']??'3306')?>">
      </div>
    </div>
    <div class="row two">
      <div>
        <label>Database Name</label>
        <input name="db_database" value="<?=h($_POST['db_database']??'')?>" placeholder="pando_db" required>
      </div>
      <div>
        <label>Username</label>
        <input name="db_username" value="<?=h($_POST['db_username']??'')?>" required>
      </div>
    </div>
    <div class="row">
      <div>
        <label>Password</label>
        <input name="db_password" type="password">
      </div>
    </div>

    <div class="checkbox-row">
      <input type="checkbox" name="seed_staff" id="seed_staff" checked>
      <label for="seed_staff" style="margin:0">Seed staff (creates Super Admin account)</label>
    </div>
    <div class="checkbox-row">
      <input type="checkbox" name="seed_workflow" id="seed_workflow" checked>
      <label for="seed_workflow" style="margin:0">Seed workflow rules (7 system automation rules)</label>
    </div>

    <h2>Mail (SendGrid)</h2>
    <div class="row">
      <div>
        <label>SendGrid API Key</label>
        <input name="sendgrid_key" value="<?=h($_POST['sendgrid_key']??'')?>" placeholder="SG.xxxxxxxx">
      </div>
    </div>

    <h2>Stripe</h2>
    <div class="row two">
      <div>
        <label>Publishable Key</label>
        <input name="stripe_key" value="<?=h($_POST['stripe_key']??'')?>">
      </div>
      <div>
        <label>Secret Key</label>
        <input name="stripe_secret" type="password">
      </div>
    </div>
    <div class="row">
      <div>
        <label>Webhook Secret</label>
        <input name="stripe_webhook" value="<?=h($_POST['stripe_webhook']??'')?>">
      </div>
    </div>

    <h2>Super Admin Account</h2>
    <div class="row two">
      <div>
        <label>Admin Email</label>
        <input name="admin_email" type="email" value="<?=h($_POST['admin_email']??'')?>" required>
      </div>
      <div>
        <label>Admin Password</label>
        <input name="admin_password" type="password" required>
      </div>
    </div>

    <h2>Security</h2>
    <div class="row">
      <div>
        <label>IP Whitelist</label>
        <input name="ip_whitelist" value="<?=h($_POST['ip_whitelist']??'127.0.0.1')?>" placeholder="1.2.3.4,5.6.7.8">
        <p class="hint">Comma-separated. Only listed IPs can access the CRM. Add your office/VPN IP here.</p>
      </div>
    </div>

    <h2>Pharmacy Details (used on PDFs)</h2>
    <div class="row two">
      <div>
        <label>GPhC Number</label>
        <input name="gphc" value="<?=h($_POST['gphc']??'')?>">
      </div>
      <div>
        <label>Phone</label>
        <input name="pharmacy_phone" value="<?=h($_POST['pharmacy_phone']??'')?>">
      </div>
    </div>
    <div class="row">
      <div>
        <label>Pharmacy Address (for PDFs)</label>
        <input name="pharmacy_address" value="<?=h($_POST['pharmacy_address']??'')?>" placeholder="1 High Street, London, SW1A 1AA">
      </div>
    </div>

    <div class="checkbox-row" style="margin-top:.5rem">
      <input type="checkbox" name="overwrite_env" id="overwrite_env">
      <label for="overwrite_env" style="margin:0">Overwrite existing .env file</label>
    </div>

    <button class="btn" type="submit">▶ Run CRM Setup</button>
  </form>

  <?php endif ?>
</div>
</body>
</html>
