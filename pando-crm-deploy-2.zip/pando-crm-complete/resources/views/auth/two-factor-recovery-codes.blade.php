<x-layouts.guest title="Recovery Codes">

    <div class="animate-fade-in">

        <div class="mb-6">
            <div class="mb-4 flex size-12 items-center justify-center rounded-2xl bg-plum-800">
                <svg class="size-6 text-lilac-300" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5
                             17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1
                             .43-1.563A6 6 0 1121.75 8.25z"/>
                </svg>
            </div>
            <h1 class="font-display text-display-sm font-bold text-plum-800">Recovery Codes</h1>
            <p class="mt-1 text-sm text-plum-400">
                Store these recovery codes somewhere safe. Each code can only be used once if you lose access to your authenticator app.
            </p>
        </div>

        <div class="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 mb-5">
            <p class="text-xs font-medium text-amber-800">
                ⚠ These codes will not be shown again. Save them now in a password manager or secure document.
            </p>
        </div>

        <div class="rounded-2xl border border-plum-100 bg-white p-5 shadow-plum-sm mb-5">
            <div class="grid grid-cols-2 gap-2">
                @foreach($codes as $code)
                    <code class="block rounded-lg bg-plum-50 px-3 py-2 text-center font-mono text-sm font-semibold text-plum-800 tracking-widest">
                        {{ $code }}
                    </code>
                @endforeach
            </div>
        </div>

        <div class="flex flex-col gap-3">
            <form method="POST" action="{{ route('two-factor.regenerate') }}">
                @csrf
                <button type="submit"
                    class="flex w-full items-center justify-center gap-2 rounded-xl border border-plum-200 px-4 py-2.5 text-sm font-semibold text-plum-600 hover:bg-plum-50 transition">
                    Regenerate Codes
                </button>
            </form>

            <a href="{{ route('dashboard') }}"
               class="flex w-full items-center justify-center gap-2 rounded-xl bg-plum-800 px-4 py-2.5 text-sm font-semibold text-lilac-200 hover:bg-plum-900 transition">
                Continue to dashboard
                <svg class="size-4" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"/>
                </svg>
            </a>
        </div>

    </div>

</x-layouts.guest>
