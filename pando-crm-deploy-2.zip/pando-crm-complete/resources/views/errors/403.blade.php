<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied — Prescribe &amp; Co CRM</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{min-height:100vh;background:#4A3050;font-family:'DM Sans',sans-serif;display:flex;align-items:center;justify-content:center;padding:24px}
        .card{background:#fff;border-radius:20px;padding:48px 40px;max-width:440px;width:100%;text-align:center;box-shadow:0 8px 40px rgba(74,48,80,0.35)}
        .icon{width:64px;height:64px;border-radius:16px;background:#fef2f2;display:flex;align-items:center;justify-content:center;margin:0 auto 24px}
        h1{font-size:22px;font-weight:700;color:#4A3050;margin-bottom:10px}
        p{font-size:14px;color:#7a5f87;line-height:1.6;margin-bottom:8px}
        a{display:inline-block;margin-top:24px;padding:10px 24px;background:#4A3050;color:#e8d8f0;border-radius:10px;font-size:14px;font-weight:600;text-decoration:none}
        a:hover{background:#3a2040}
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">
            <svg width="28" height="28" fill="none" viewBox="0 0 24 24" stroke="#dc2626" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71
                         c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898
                         0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"/>
            </svg>
        </div>
        <h1>Access Denied</h1>
        <p>You do not have permission to access this area.</p>
        <p>If you believe this is a mistake, contact your system administrator.</p>
        <a href="{{ url()->previous() !== url()->current() ? url()->previous() : route('dashboard') }}">
            Go back
        </a>
    </div>
</body>
</html>
