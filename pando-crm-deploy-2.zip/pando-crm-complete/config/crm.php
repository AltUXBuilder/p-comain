<?php

return [

    'ip_whitelist' => array_filter(
        explode(',', env('CRM_IP_WHITELIST', '127.0.0.1,::1'))
    ),

    'gphc_regex' => '/^\d{7}$/',

    'welcome_token_ttl' => 72,

    'session_driver'   => 'database',
    'session_lifetime' => 480,

    'consultation_review_threshold_hours' => env('CRM_CONSULTATION_REVIEW_THRESHOLD_HOURS', 24),

    'suspicious_login_hours_start' => env('CRM_SUSPICIOUS_LOGIN_HOURS_START', 7),
    'suspicious_login_hours_end'   => env('CRM_SUSPICIOUS_LOGIN_HOURS_END', 22),

    'pharmacy' => [
        'name'        => env('PHARMACY_NAME',        'Prescribe & Co'),
        'address'     => env('PHARMACY_ADDRESS',     ''),
        'gphc_number' => env('PHARMACY_GPHC_NUMBER', ''),
        'phone'       => env('PHARMACY_PHONE',       ''),
        'email'       => env('PHARMACY_EMAIL',       'pharmacy@prescribeandco.co.uk'),
    ],

];
